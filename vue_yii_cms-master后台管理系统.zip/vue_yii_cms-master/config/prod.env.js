'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: '"http://api.github.mooov.cn"',
  PC_DOMAIN:'"https://www.shanhuxueyuan.com"',
  M_DOMAIN:'"https://m.shanhuxueyuan.com"'
}
