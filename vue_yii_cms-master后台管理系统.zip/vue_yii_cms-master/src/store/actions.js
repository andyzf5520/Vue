import * as types from './mutation-types'
import netwrok from '../utils/base/network'
import config from '../utils/config/config'
import api from '../utils/config/api'
import dynamicRouter from '../router/dynamic-router'
import store from "./index";
import router from "../router";
export  default {


}
