export default {

  pagesize: state => state.pagesize,

}
