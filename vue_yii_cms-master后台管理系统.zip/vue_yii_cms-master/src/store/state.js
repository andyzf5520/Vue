export default {
  pagesize:20,
  breadcrumb:[],
  router:[],
  menu:[],
  menu_loaded:false,
  nickname:'',


}
