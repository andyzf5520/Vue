export default {
  mounted:function () {
    console.log("mounted mounted mounted")
    this.$toast({
      title:'测试一下'
    })
  }
}
